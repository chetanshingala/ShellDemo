﻿using System;
using System.Threading.Tasks;
using ShellDemo.Views.Login;
using ShellDemo.Views.Transactions;
using Xamarin.Forms;

namespace ShellDemo.ViewModels
{
    public class AppShellViewModel : BaseViewModel
    {
        public AppShellViewModel()
        {
        }

        public Command SignoutCommand { get { return new Command(async () => await OnSignoutCommandExecuted()); } }

        private async Task OnSignoutCommandExecuted()
        {
            var result = await Shell.Current.DisplayAlert("Alert", "Are you sure ? You want to Signout?", "Yes", "No");
            if (result)
            {
                App.Current.MainPage = new LoginPage();
            }
        }

        
    }
}
