﻿using System;
using System.Threading.Tasks;
using ShellDemo.Views.AboutUs;
using Xamarin.Forms;

namespace ShellDemo.ViewModels
{
    public class WithdrawnTransactionPageViewModel : BaseViewModel
    {
        public WithdrawnTransactionPageViewModel()
        {
        }

        public Command AboutUsCommand { get { return new Command(async () => await OnAboutUsCommandExecuted()); } }
        private async Task OnAboutUsCommandExecuted()
        {
            await Shell.Current.GoToAsync($"{nameof(AboutUsPage)}");
        }
    }
}
