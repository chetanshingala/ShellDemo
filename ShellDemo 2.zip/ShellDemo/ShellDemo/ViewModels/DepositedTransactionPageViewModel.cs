﻿using System;
using System.Threading.Tasks;
using ShellDemo.Views.AboutUs;
using Xamarin.Forms;

namespace ShellDemo.ViewModels
{
    public class DepositedTransactionPageViewModel : BaseViewModel
    {
        public DepositedTransactionPageViewModel()
        {
        }

        public Command ContactUsCommand { get { return new Command(async() => await OnContactUsCommandExecuted()); } }
        private async Task OnContactUsCommandExecuted()
        {
            await Shell.Current.GoToAsync($"{nameof(ContactUsPage)}");
        }
    }
}
