﻿using System;
using Xamarin.Forms;

namespace ShellDemo.ViewModels
{
    public class LoginPageViewModel : BaseViewModel
    {
        public LoginPageViewModel()
        {
        }

        public Command LoginCommand { get { return new Command(OnLoginCommandExecuted); } }
        private void OnLoginCommandExecuted()
        {
            App.Current.MainPage = new AppShell();
        }
    }
}
