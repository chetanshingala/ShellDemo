﻿using System;
using System.Collections.Generic;
using ShellDemo.ViewModels;
using ShellDemo.Views;
using ShellDemo.Views.AboutUs;
using ShellDemo.Views.Assets;
using ShellDemo.Views.Transactions;
using ShellDemo.Views.Wallet;
using Xamarin.Forms;

namespace ShellDemo
{
    public partial class AppShell : Xamarin.Forms.Shell
    {
        public AppShell()
        {
            InitializeComponent();
            BindingContext = new AppShellViewModel();
            Routing.RegisterRoute(nameof(WalletPage), typeof(WalletPage));
            Routing.RegisterRoute(nameof(AssetsPage), typeof(AssetsPage));
            Routing.RegisterRoute(nameof(DepositedTransactionPage), typeof(DepositedTransactionPage));
            Routing.RegisterRoute(nameof(TransactionsPage), typeof(TransactionsPage));
            Routing.RegisterRoute(nameof(WithdrawnTransactionPage), typeof(WithdrawnTransactionPage));
            Routing.RegisterRoute(nameof(ContactUsPage), typeof(ContactUsPage));
            Routing.RegisterRoute(nameof(AboutUsPage), typeof(AboutUsPage));


        }

        private async void OnMenuItemClicked(object sender, EventArgs e)
        {
            await Shell.Current.GoToAsync("//LoginPage");
        }

        protected override void OnAppearing()
        {
            base.OnAppearing();
        }
    }
}
