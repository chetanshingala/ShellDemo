﻿using System;
using System.Collections.Generic;

using Xamarin.Forms;

namespace ShellDemo.Views.Transactions
{
    public partial class WithdrawnTransactionPage : ContentPage
    {
        public WithdrawnTransactionPage()
        {
            InitializeComponent();
        }
    }
}
