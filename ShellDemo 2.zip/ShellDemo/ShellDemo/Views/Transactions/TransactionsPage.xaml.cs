﻿using System;
using System.Collections.Generic;

using Xamarin.Forms;

namespace ShellDemo.Views.Transactions
{
    public partial class TransactionsPage : ContentPage
    {
        public TransactionsPage()
        {
            InitializeComponent();
        }
    }
}
