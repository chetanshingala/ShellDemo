﻿using System;
using System.Collections.Generic;

using Xamarin.Forms;

namespace ShellDemo.Views.Transactions
{
    public partial class DepositedTransactionPage : ContentPage
    {
        public DepositedTransactionPage()
        {
            InitializeComponent();
        }
    }
}
