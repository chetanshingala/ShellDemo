﻿using System;
using System.Collections.Generic;

using Xamarin.Forms;

namespace ShellDemo.Views.Login
{
    public partial class LoginPage : ContentPage
    {
        public LoginPage()
        {
            InitializeComponent();
        }
    }
}
