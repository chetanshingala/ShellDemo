﻿using System;
using System.Collections.Generic;

using Xamarin.Forms;

namespace ShellDemo.Views.AboutUs
{
    public partial class ContactUsPage : ContentPage
    {
        public ContactUsPage()
        {
            InitializeComponent();
        }
    }
}
