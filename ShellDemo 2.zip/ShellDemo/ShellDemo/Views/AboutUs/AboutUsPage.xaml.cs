﻿using System;
using System.Collections.Generic;

using Xamarin.Forms;

namespace ShellDemo.Views.AboutUs
{
    public partial class AboutUsPage : ContentPage
    {
        public AboutUsPage()
        {
            InitializeComponent();
        }
    }
}
