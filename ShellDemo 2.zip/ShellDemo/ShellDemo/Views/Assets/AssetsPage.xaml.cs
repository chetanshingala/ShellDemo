﻿using System;
using System.Collections.Generic;

using Xamarin.Forms;

namespace ShellDemo.Views.Assets
{
    public partial class AssetsPage : ContentPage
    {
        public AssetsPage()
        {
            InitializeComponent();
        }
    }
}
